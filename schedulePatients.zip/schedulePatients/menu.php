<nav class="navbar navbar-expand navbar-dark bg-dark mb-5">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link"href="<?php echo ROOT ?>">ver calendario</a>
</li>
<li class="nav-item">
<a class="nav-link"href="<?=ROOT?>/clientes/add.php">registrar datos</a>

</li>
</ul>

</nav>