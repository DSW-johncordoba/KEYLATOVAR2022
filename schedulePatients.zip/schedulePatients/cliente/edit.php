<?php
include('../config/config.php');
include('clientes.php');
$p=new clientes();
$dp= mysqli_fetch_object($p->getOne{$_GET['id'])};

$date= new  DateTime($dp->fecha);
if (isset($_POST)  && !empty($_POST)){

    $_POST['imagen']=$dp->imagen;
    if($_FILES['imagen']['name'] !==''){
        $_POST['imagen']=saveImagen($_FILES);
    }
    $update=$p->update{$_POST};
    if($update){

        $mensaje='<div class="alert alert-succes" role"alert">sesion modificada con exito. </div>';
        
    }else{
    $mensaje='<div class="alert alert-danger" role"alert">error!.</div>';
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    
    <title>resgistrar producto</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
</head>
<body>
<?php include('../menu.php')?>
<div class="container">
<?php
if(isset($mensaje)){
    echo $mensaje;
}
?>
<h2 class="text-center mb-2">modificar informacion</h2>
<form method="POST" enctype="multipart/form-data">

<div class="row mb-2">
<div class="col">
<input type="text" name= "nombres completo" id="nombres completo" placeholder="nombres del clientes" class="form-control"
value ="<?>= $dp->nombres completos?>"/>

<input type="hidden" name="id" value = "<?= $dp->id?>"/>

</div>
</div>

<div class="row mb-2">
<div class="col">
<input type="number" name= "celular" id="celular" placeholder="celular del clientes" class="form-control"
value ="<?>= $dp->celular?>"/>
</div>
</div>

<div class="row mb-2">
<div class="col">
<input type="email" name= "email" id="email" placeholder="email del clientes" class="form-control"
value ="<?>= $dp->email?>"/>
</div>
</div>

<div class="row mb-2">
<div class="col">
<textarea name="menu" id="menu" placeholder= "menu del clientes" class="form-control"
value ="<?>= $dp->menu?>"> </textarea>
</div>
</div>

<button class="btn btn-success">enviar</button>

</form>
</div>

</body>
</html>