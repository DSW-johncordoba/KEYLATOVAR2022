<?php
include_one('..config/config.php');
include('clientes.php');

$p=new clientes ();
$data= $p->getALL();

if(isset($_GET['id']) && !empty($_GET['id'])){
    if $remove= $p->delete ($_GET['id']){
        header('Location:' .ROOT.'/clientes/index.php');
    
    }else{
        $mensaje= '<div class="alert alert-danger" role ="alert"> error al eliminar</div>';
    }
    
    }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    
    <title>directorio</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
<?php include('../menu.php')?>
<div class="container"></div>
<H2 class="text-center mb-2"> calendario</H2>
<div class="row">
<?php
while($pt = mysqli_fetch_object ($data)){
    echo "<div class='col' >";
    echo "<div class='border border-info p-2'>";
    echo" < div class= 'text-center'>";
    echo "<a class= 'btn  btn-success' href=".ROOT."/clientes/edit.php?id=$pt->id'>MODIFICAR></a> - <a class='btn btn-danger' href=".ROOT."/clientes/index.php?id=$pt->id'> eliminar </a>";
    echo "</div>";
    echo "</div>";
    echo "</div>";


}
</div>
</div>
</body>
</html>