<?php
include_once('../config/config.php');
include('clientes.php');
if(isset($_post) && !empty($_POST)){
    $p= new clientes ();
    
    
    }
$save=$p->save($_POST);
if($save){
$mensaje='<div class="alert alert_success"> sesion registrada </div>';

}else{
    $mensaje='<div class="alert alert_danger"> sesion registrar! </div>';

}


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    
    <title>resgistrar producto</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
</head>
<body>
<?php include('../menu.php')?>
<div class="container">
<?php
if(isset($mensaje)){
    echo $mensaje;
}
?>
<h2 class="text-center mb-2">registrar producto</h2>
<form method="POST" enctype="multipart/form-data">

<div class="row mb-2">
<div class="col">
<input type="text" name= "nombres completo" id="nombres completo" placeholder="nombres del clientes" class="form-control"/>
</div>
</div>

<div class="row mb-2">
<div class="col">
<input type="number" name= "celular" id="celular" placeholder="celular del clientes" class="form-control"/>
</div>
</div>

<div class="row mb-2">
<div class="col">
<input type="email" name= "email" id="email" placeholder="email del clientes" class="form-control"/>
</div>
</div>

<div class="row mb-2">
<div class="col">
<textarea name="menu" id="menu" placeholder= "menu del clientes" class="form-control"> </textarea>
</div>
</div>

<button class="btn btn-success">enviar</button>

</form>
</div>

</body>
</html>