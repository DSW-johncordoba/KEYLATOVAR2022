<?php

include_once("../config/config.php");
include("../config/database.php");

class clientes {

    public $conexion;

    function _construct()
    {
        sdb = new database();
        $this->conexion = $db-> connecttodabase();
    }

    function save( $params ){
        $nombres= $params("nombres completo");
        $celular= $params("celular");
        $email= $params("email");
        $menu= $params("menu");

        $insert ="INSERT INTO clientes VALUES (NULL,"$nombrescompleto", $celular , "$email", "$menu")";
        return mysqli_query($this->conexion, $insert);


    function getALL(){
        $sql "SELECT * FROM clientes";
        return mysqli_query($this->conexion, $sql);

    }
    function getOne($id){
        $sql="SELECT * FROM  cliente WHERE  id = $id";
        return mysqli_query($this->conexion, $sql);

}
function getOne($id){
    $sql="SELECT * FROM  ckientes WHERE  id = $id";

    }
    function update($params){
        $nombres= $params("nombres completo");
        $celular= $params("celular");
        $email= $params("email");
        $menu= $params("menu");];

      $update="UPDATE clientes  SET  nombres = '$nombres', celular='$celular', email='$email', menu='$menu' WERE id=$id ";
       return mysqli_query($this->conexion, $update);
    }
    function  delete($id){
        $delete = "DELETE FROM clientes WHERE id=$id";
      return mysqli_query($this->conexion,$delete);
    }
   
}

?>