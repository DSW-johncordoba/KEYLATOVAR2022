<?php

function getfolderproyect()/* con este es obtener la ruta de localhots */{
/* me permite imprimir docmuentos en el navegador */
if (strpos(_DIR_, '/') !== false) {
    $root = str_replace('/opt/lampp/htdocs/', '/', _DIR_);
  } else {
    $root = str_replace('C:\\XboxGames\\xampp\\htdocs\\', '/', _DIR_);
  }
  $root = str_replace('config', '', $root);
  return $root;

}
function saveImagen($file){
    $imageName = str_replace(' ','',$file['imagen']['name'] );
    $imgTmp =$file['imagen']['tmp_name'];
    move_uploaded_file($simgTmp, $_SERVER['DOCUMENT_ROOT'].getfolderproyect().'/images/'.$imageName);
    return $imageName;

}
?>
