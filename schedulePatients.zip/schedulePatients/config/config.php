
<<?php
include_once('funciones.php');
if(!defined('ROOT')){
define('ROOT', 'http://'. $_SERVER['HTTP_HOST']. getfolderproyect());
}
?>


