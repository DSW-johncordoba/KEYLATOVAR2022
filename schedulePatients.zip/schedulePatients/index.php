<?php
include('config/config.php');



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    
    <title>contactenos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>

<body>

<?php include ('menu.php')?>

<nav class="navbar navbar-expand navbar-dark bg-dark mb-5">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link"href="<?php echo ROOT ?>">ver calendario</a>
</li>
<li class="nav-item">
<a class="nav-link"href="<?=ROOT?>/clientes/add.php">registrar datos</a>

</li>
</ul>

</nav>

<div class="container">
<h1 class="text-center">contactenos</h1>

</div>

</body>
</html>